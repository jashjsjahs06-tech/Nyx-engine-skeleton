/**
 * Nyx Engine - Public C API
 * Lightweight C11 core with high-level game development layer.
 *
 * Design principle: Easy game creation first, advanced customization second.
 */

#ifndef NYX_H
#define NYX_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* -------------------------------------------------------------------------- */
/* Version & Configuration                                                     */
/* -------------------------------------------------------------------------- */

#define NYX_VERSION_MAJOR 0
#define NYX_VERSION_MINOR 1
#define NYX_VERSION_PATCH 0

#ifndef NYX_API
#  if defined(_WIN32) || defined(__CYGWIN__)
#    ifdef NYX_BUILD
#      define NYX_API __declspec(dllexport)
#    else
#      define NYX_API __declspec(dllimport)
#    endif
#  else
#    define NYX_API __attribute__((visibility("default")))
#  endif
#endif

/* -------------------------------------------------------------------------- */
/* Forward Declarations                                                        */
/* -------------------------------------------------------------------------- */

typedef struct NyxGame      NyxGame;
typedef struct NyxScene     NyxScene;
typedef struct NyxObject    NyxObject;
typedef struct NyxComponent NyxComponent;
typedef struct NyxCamera    NyxCamera;
typedef struct NyxTexture   NyxTexture;
typedef struct NyxSound     NyxSound;
typedef struct NyxMesh      NyxMesh;
typedef struct NyxMaterial  NyxMaterial;
typedef struct NyxAnimation NyxAnimation;
typedef struct NyxPrefab    NyxPrefab;

/* -------------------------------------------------------------------------- */
/* Types & Enums                                                               */
/* -------------------------------------------------------------------------- */

typedef enum {
    NYX_BODY_STATIC = 0,
    NYX_BODY_KINEMATIC,
    NYX_BODY_DYNAMIC
} NyxBodyType;

typedef enum {
    NYX_KEY_SPACE = 32,
    NYX_KEY_A = 'A', NYX_KEY_B, NYX_KEY_C, NYX_KEY_D, NYX_KEY_E, NYX_KEY_F,
    NYX_KEY_G, NYX_KEY_H, NYX_KEY_I, NYX_KEY_J, NYX_KEY_K, NYX_KEY_L,
    NYX_KEY_M, NYX_KEY_N, NYX_KEY_O, NYX_KEY_P, NYX_KEY_Q, NYX_KEY_R,
    NYX_KEY_S, NYX_KEY_T, NYX_KEY_U, NYX_KEY_V, NYX_KEY_W, NYX_KEY_X,
    NYX_KEY_Y, NYX_KEY_Z,
    NYX_KEY_LEFT  = 256,
    NYX_KEY_RIGHT,
    NYX_KEY_UP,
    NYX_KEY_DOWN,
    NYX_KEY_ESCAPE,
    NYX_KEY_ENTER,
    NYX_KEY_SHIFT,
    NYX_KEY_CTRL,
    NYX_KEY_COUNT
} NyxKey;

typedef enum {
    NYX_MOUSE_LEFT = 0,
    NYX_MOUSE_RIGHT,
    NYX_MOUSE_MIDDLE
} NyxMouseButton;

typedef struct {
    float x, y;
} NyxVec2;

typedef struct {
    float x, y, z;
} NyxVec3;

typedef struct {
    float x, y, z, w;
} NyxVec4;

typedef struct {
    float m[16]; /* column-major */
} NyxMat4;

typedef struct {
    float r, g, b, a;
} NyxColor;

/* -------------------------------------------------------------------------- */
/* Game Lifecycle                                                              */
/* -------------------------------------------------------------------------- */

/**
 * User-provided callbacks. Register these before calling nyx_run().
 */
typedef struct {
    void (*on_start)(NyxGame *game);
    void (*on_update)(NyxGame *game, float delta_time);
    void (*on_fixed_update)(NyxGame *game, float fixed_dt);
    void (*on_render)(NyxGame *game);
    void (*on_stop)(NyxGame *game);
} NyxGameCallbacks;

NYX_API NyxGame *nyx_game_create(const char *title, int width, int height);
NYX_API void     nyx_game_destroy(NyxGame *game);
NYX_API void     nyx_game_set_callbacks(NyxGame *game, const NyxGameCallbacks *cb);
NYX_API int      nyx_run(NyxGame *game); /* main loop, returns exit code */

NYX_API void nyx_set_gravity(NyxGame *game, float x, float y); /* 2D gravity (x,y) */
NYX_API void nyx_set_gravity3(NyxGame *game, float x, float y, float z);

NYX_API float nyx_get_delta_time(const NyxGame *game);
NYX_API float nyx_get_time(const NyxGame *game);
NYX_API int   nyx_get_width(const NyxGame *game);
NYX_API int   nyx_get_height(const NyxGame *game);

/* -------------------------------------------------------------------------- */
/* Scene Management                                                            */
/* -------------------------------------------------------------------------- */

NYX_API NyxScene *nyx_scene_create(NyxGame *game);
NYX_API void      nyx_scene_destroy(NyxScene *scene);
NYX_API void      nyx_scene_set_active(NyxGame *game, NyxScene *scene);
NYX_API NyxScene *nyx_scene_get_active(NyxGame *game);

NYX_API bool nyx_scene_save(NyxScene *scene, const char *path);
NYX_API NyxScene *nyx_scene_load(NyxGame *game, const char *path);

/* -------------------------------------------------------------------------- */
/* GameObject System                                                           */
/* -------------------------------------------------------------------------- */

NYX_API NyxObject *nyx_object_create(NyxScene *scene, const char *name);
NYX_API void       nyx_object_destroy(NyxObject *obj);
NYX_API NyxObject *nyx_object_find(NyxScene *scene, const char *name);
NYX_API const char *nyx_object_get_name(const NyxObject *obj);

/* Hierarchy */
NYX_API void nyx_object_set_parent(NyxObject *obj, NyxObject *parent);
NYX_API NyxObject *nyx_object_get_parent(const NyxObject *obj);
NYX_API int  nyx_object_get_child_count(const NyxObject *obj);
NYX_API NyxObject *nyx_object_get_child(const NyxObject *obj, int index);

/* Transform */
NYX_API void nyx_object_set_position(NyxObject *obj, float x, float y, float z);
NYX_API void nyx_object_set_position2(NyxObject *obj, float x, float y);
NYX_API NyxVec3 nyx_object_get_position(const NyxObject *obj);

NYX_API void nyx_object_set_rotation(NyxObject *obj, float x, float y, float z); /* degrees */
NYX_API void nyx_object_set_rotation2(NyxObject *obj, float degrees);
NYX_API NyxVec3 nyx_object_get_rotation(const NyxObject *obj);

NYX_API void nyx_object_set_scale(NyxObject *obj, float x, float y, float z);
NYX_API void nyx_object_set_scale2(NyxObject *obj, float x, float y);
NYX_API NyxVec3 nyx_object_get_scale(const NyxObject *obj);

/* Prefabs / Instancing */
NYX_API NyxPrefab *nyx_prefab_create(NyxObject *source);
NYX_API NyxObject *nyx_prefab_instantiate(NyxScene *scene, NyxPrefab *prefab);
NYX_API void       nyx_prefab_destroy(NyxPrefab *prefab);

/* -------------------------------------------------------------------------- */
/* Components (high-level helpers)                                             */
/* -------------------------------------------------------------------------- */

/* Sprite (2D) */
NYX_API void nyx_add_sprite(NyxObject *obj, const char *texture_path);
NYX_API void nyx_add_sprite_color(NyxObject *obj, const char *texture_path, NyxColor tint);
NYX_API void nyx_sprite_set_flip(NyxObject *obj, bool flip_x, bool flip_y);

/* 3D Model */
NYX_API void nyx_add_model(NyxObject *obj, const char *model_path); /* glTF / GLB / OBJ */

/* Camera */
NYX_API NyxCamera *nyx_add_camera(NyxObject *obj);
NYX_API void       nyx_camera_set_orthographic(NyxCamera *cam, float size);
NYX_API void       nyx_camera_set_perspective(NyxCamera *cam, float fov_degrees, float near, float far);
NYX_API void       nyx_camera_set_active(NyxGame *game, NyxCamera *cam);

/* Physics */
NYX_API void nyx_add_rigidbody(NyxObject *obj, NyxBodyType type);
NYX_API void nyx_add_box_collider(NyxObject *obj, float width, float height);
NYX_API void nyx_add_box_collider3(NyxObject *obj, float w, float h, float d);
NYX_API void nyx_add_circle_collider(NyxObject *obj, float radius);
NYX_API void nyx_add_sphere_collider(NyxObject *obj, float radius);

NYX_API void nyx_rigidbody_set_velocity(NyxObject *obj, float vx, float vy);
NYX_API void nyx_rigidbody_set_velocity3(NyxObject *obj, float vx, float vy, float vz);
NYX_API NyxVec2 nyx_rigidbody_get_velocity(const NyxObject *obj);
NYX_API void nyx_rigidbody_add_force(NyxObject *obj, float fx, float fy);
NYX_API void nyx_rigidbody_set_mass(NyxObject *obj, float mass);

/* Animation */
NYX_API void nyx_add_animation(NyxObject *obj, const char *anim_path);
NYX_API void nyx_play_animation(NyxObject *obj, const char *name, bool loop);
NYX_API void nyx_stop_animation(NyxObject *obj);

/* -------------------------------------------------------------------------- */
/* Assets                                                                      */
/* -------------------------------------------------------------------------- */

NYX_API NyxTexture *nyx_load_texture(NyxGame *game, const char *path);
NYX_API NyxSound   *nyx_load_sound(NyxGame *game, const char *path);
NYX_API NyxMesh    *nyx_load_mesh(NyxGame *game, const char *path);

NYX_API void nyx_play_sound(NyxGame *game, const char *path); /* convenience: load+play */
NYX_API void nyx_play_sound_id(NyxSound *sound, float volume, bool loop);
NYX_API void nyx_stop_sound(NyxSound *sound);

/* Supported: PNG, JPG, WAV, OGG, GLTF, GLB, OBJ, TTF */

/* -------------------------------------------------------------------------- */
/* Input                                                                       */
/* -------------------------------------------------------------------------- */

NYX_API bool nyx_input_pressed(NyxKey key);   /* true only on the frame it was pressed */
NYX_API bool nyx_input_down(NyxKey key);      /* true while held */
NYX_API bool nyx_input_released(NyxKey key);

NYX_API bool nyx_mouse_pressed(NyxMouseButton btn);
NYX_API bool nyx_mouse_down(NyxMouseButton btn);
NYX_API NyxVec2 nyx_mouse_position(void);
NYX_API NyxVec2 nyx_mouse_delta(void);

/* Touch (Android) */
NYX_API int  nyx_touch_count(void);
NYX_API NyxVec2 nyx_touch_position(int index);

/* -------------------------------------------------------------------------- */
/* Scripting                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Attach a C script (function pointers) or Lua script to an object.
 */
typedef struct {
    void (*on_start)(NyxObject *self);
    void (*on_update)(NyxObject *self, float dt);
    void (*on_collision_enter)(NyxObject *self, NyxObject *other);
    void (*on_collision_exit)(NyxObject *self, NyxObject *other);
    void (*on_destroy)(NyxObject *self);
} NyxScript;

NYX_API void nyx_add_script(NyxObject *obj, const NyxScript *script);
NYX_API void nyx_add_lua_script(NyxObject *obj, const char *lua_path); /* optional */

/* -------------------------------------------------------------------------- */
/* Renderer surface (portable CPU fallback; window backends can present pixels) */
NYX_API void nyx_render_surface_resize(int width, int height);
NYX_API void nyx_render_surface_clear(NyxColor color);
NYX_API void nyx_render_rect(int x, int y, int width, int height, NyxColor color);
NYX_API const uint32_t *nyx_render_pixels(int *width, int *height);
NYX_API void nyx_render_shutdown(void);

/* -------------------------------------------------------------------------- */
/* Utility                                                                     */
/* -------------------------------------------------------------------------- */

NYX_API void nyx_log(const char *fmt, ...);
NYX_API void nyx_log_error(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* NYX_H */
