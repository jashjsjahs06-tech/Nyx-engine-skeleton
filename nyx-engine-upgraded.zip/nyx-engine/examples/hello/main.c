/**
 * Minimal Nyx Engine example – matches the illustrative API from the requirements.
 *
 * Build (after implementing real platform layer):
 *   cmake -B build && cmake --build build
 *   ./build/examples/hello
 */

#include <nyx/nyx.h>

static void on_start(NyxGame *game)
{
    NyxScene *scene = nyx_scene_create(game);

    NyxObject *player = nyx_object_create(scene, "Player");
    nyx_object_set_position2(player, 100.0f, 100.0f);

    nyx_add_sprite(player, "assets/player.png");
    nyx_add_rigidbody(player, NYX_BODY_DYNAMIC);
    nyx_add_box_collider(player, 32, 32);

    /* Simple ground */
    NyxObject *ground = nyx_object_create(scene, "Ground");
    nyx_object_set_position2(ground, 0.0f, 400.0f);
    nyx_add_sprite(ground, "assets/ground.png");
    nyx_add_rigidbody(ground, NYX_BODY_STATIC);
    nyx_add_box_collider(ground, 800, 32);

    /* Camera */
    NyxObject *cam_obj = nyx_object_create(scene, "MainCamera");
    NyxCamera *cam = nyx_add_camera(cam_obj);
    nyx_camera_set_orthographic(cam, 360.0f);
    nyx_camera_set_active(game, cam);

    nyx_set_gravity(game, 0.0f, 980.0f);

    nyx_log("Hello Nyx – scene ready. Press SPACE to play jump sound (stub).");
}

static void on_update(NyxGame *game, float delta_time)
{
    (void)delta_time;

    if (nyx_input_pressed(NYX_KEY_SPACE)) {
        nyx_play_sound(game, "assets/jump.wav");
        nyx_log("Jump!");
    }

    if (nyx_input_pressed(NYX_KEY_ESCAPE)) {
        /* In a real build this would set game->running = false */
        nyx_log("Escape pressed (exit not wired in stub platform)");
    }
}

int main(void)
{
    NyxGame *game = nyx_game_create("Nyx Hello", 1280, 720);
    if (!game) return 1;

    NyxGameCallbacks cb = {0};
    cb.on_start  = on_start;
    cb.on_update = on_update;
    nyx_game_set_callbacks(game, &cb);

    int code = nyx_run(game);
    nyx_game_destroy(game);
    return code;
}
