# Android ARM64 export scaffold

This folder is a starting point for Android NDK packaging. It is not yet a turnkey APK exporter: a real Android app entry point, EGL/NativeActivity window backend, asset packaging, and signing configuration must be supplied.

1. Install Android Studio + NDK + CMake.
2. Configure CMake with `-DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24`.
3. Implement the platform window/input bridge before expecting interactive rendering.
4. Package assets under the app's assets directory and sign the release APK.
