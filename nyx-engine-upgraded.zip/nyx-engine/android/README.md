# Android ARM64 export scaffold

Nyx currently builds a portable C static library. Android APK export requires an Android NDK installation and an application shell. This directory contains the CMake toolchain entry point; it does **not** claim to provide a complete Android activity, renderer, input bridge, or packaged APK yet.

Example (from the project root):

```sh
cmake -S . -B build-android \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 \
  -DNYX_BUILD_EXAMPLES=OFF
cmake --build build-android
```

The result is a native library. Place it in an Android Gradle application's `app/src/main/jniLibs/arm64-v8a/` and provide a Java/Kotlin Activity or NativeActivity before producing an APK.
