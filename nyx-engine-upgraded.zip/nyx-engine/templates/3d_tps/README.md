# 3D Tps

Third-person controller starter. This is a project layout starter; gameplay controllers and 3D rendering backend are not yet included.
