#include <nyx/nyx.h>
static NyxObject *player;
static void start(NyxGame *game) {
    NyxScene *scene = nyx_scene_create(game);
    nyx_scene_set_active(game, scene);
    player = nyx_object_create(scene, "Player");
    nyx_object_set_position2(player, 0.0f, 0.0f);
    nyx_add_sprite_color(player, NULL, (NyxColor){0.2f, 0.7f, 1.0f, 1.0f});
}
static void update(NyxGame *game, float dt) {
    (void)game;
    NyxVec3 p = nyx_object_get_position(player);
    float speed = 180.0f * dt;
    if (nyx_input_down(NYX_KEY_A)) p.x -= speed;
    if (nyx_input_down(NYX_KEY_D)) p.x += speed;
    if (nyx_input_down(NYX_KEY_W)) p.y -= speed;
    if (nyx_input_down(NYX_KEY_S)) p.y += speed;
    nyx_object_set_position(player, p.x, p.y, p.z);
}
int main(void) {
    NyxGame *game = nyx_game_create("Nyx Top-down", 960, 540);
    NyxGameCallbacks cb = {0}; cb.on_start = start; cb.on_update = update;
    nyx_game_set_callbacks(game, &cb);
    int result = nyx_run(game); nyx_game_destroy(game); return result;
}
