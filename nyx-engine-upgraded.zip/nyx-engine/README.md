# Nyx Engine

**Lightweight C11 game engine focused on easy game development.**

> Main design principle: *Easy game creation first, advanced customization second.*

Nyx provides a high-level, Unity/Godot-like API on top of a minimal native core so beginners can create games with very little code, while still allowing deep control when needed.

## Current Status (v0.1.1 foundation upgrade)

This revision adds working foundational systems while keeping optional platform dependencies out of the default build:

- C11 scene / object / component core and hierarchy
- Fixed-step 2D rigidbody integration (gravity, force, mass) and basic AABB box collision response
- Portable CPU framebuffer API (`nyx_render_surface_*`, `nyx_render_rect`)
- Browser-based scene editor preview with hierarchy, inspector, canvas view and JSON save/load
- Android ARM64 NDK CMake preset and export documentation scaffold
- Six template manifests: platformer, shooter, top-down, 3D exploration, FPS and TPS

**Important:** this is still an early engine foundation, not a production-ready Unity/Godot replacement. The default renderer is a CPU framebuffer, not OpenGL GPU rendering. Full GLFW/OpenGL presentation, Box2D/Jolt, audio decoding/mixing, Lua runtime bindings, glTF/OBJ parsing, integrated editor play mode and complete Android APK packaging remain future integration work. See `docs/IMPLEMENTATION_STATUS.md`.

## Quick Start (API style)

```c
#include <nyx/nyx.h>

void game_start(NyxGame *game)
{
    NyxScene *scene = nyx_scene_create(game);

    NyxObject *player = nyx_object_create(scene, "Player");
    nyx_add_sprite(player, "assets/player.png");
    nyx_add_rigidbody(player, NYX_BODY_DYNAMIC);
    nyx_add_box_collider(player, 32, 32);

    nyx_set_gravity(game, 0.0f, 980.0f);
}

void game_update(NyxGame *game, float delta_time)
{
    (void)delta_time;
    if (nyx_input_pressed(NYX_KEY_SPACE)) {
        nyx_play_sound(game, "assets/jump.wav");
    }
}
```

See `examples/hello/main.c` for a complete runnable example (currently runs with stub platform).

## Building

```bash
cd nyx-engine
cmake -B build -DNYX_BUILD_EXAMPLES=ON
cmake --build build
./build/hello          # core API smoke test (platform window backend is not enabled)
```

Requirements: C11 compiler (GCC / Clang / MSVC), CMake ≥ 3.16.

## Architecture Overview

```
include/nyx/nyx.h          ← Public high-level API (what beginners use)
src/
  core/                    ← Game loop, logging, internal structures
  scene/                   ← Scenes, Objects, Components, Prefabs
  render/                  ← (future) Renderer abstraction
  physics/                 ← (future) Physics world
  audio/                   ← (future) Audio
  input/                   ← Input state
  assets/                  ← Resource loading & management
  script/                  ← C + optional Lua
  platform/                ← Window, OS, Android
editor/                    ← Visual editor (future)
templates/                 ← Ready-made project templates
```

### Core Concepts

| Concept        | Description                                      |
|----------------|--------------------------------------------------|
| **NyxGame**    | Application + main loop                          |
| **NyxScene**   | Collection of objects, can be saved/loaded       |
| **NyxObject**  | Entity with transform + components + hierarchy   |
| **Components** | Sprite, Rigidbody, Collider, Camera, Script…     |
| **Prefabs**    | Instantiable object templates                    |

## Roadmap (aligned with requirements)

### Phase 1 – Core Playable (current → next)
- [x] Public C API design
- [x] Scene / Object / Component foundation
- [ ] Real platform layer (GLFW + OpenGL or Vulkan)
- [ ] 2D rendering (sprites, cameras)
- [ ] Basic 2D physics integration
- [ ] Asset loading (PNG, WAV via stb / miniaudio)

### Phase 2 – Usability
- [ ] Scene serialization (JSON)
- [ ] Prefabs & instancing
- [ ] C scripting fully wired + collision callbacks
- [ ] Optional Lua scripting
- [ ] Project templates (2D Platformer first)

### Phase 3 – Visual Editor
- [ ] Desktop editor (Linux + Windows)
- [ ] Panels: Hierarchy, Viewport, Inspector, Asset Browser, Console, Project Settings, Animation
- [ ] Drag-and-drop, property editing, play-in-editor

### Phase 4 – Platforms & Polish
- [ ] Android toolchain (ARM64, APK export, touch)
- [ ] 3D rendering path (glTF)
- [ ] Remaining templates
- [ ] Documentation & beginner tutorials

## Design Goals (from requirements)

1. **Simple Game API** – create a basic game with very little code.
2. **Visual Editor** – build games without writing everything by hand.
3. **Scene & Object System** – Unity/Godot-like workflow.
4. **Scripting** – C API + optional Lua.
5. **Templates** – 2D Platformer, Top-down, Shooter, 3D FPS/TPS/Exploration.
6. **Asset Workflow** – PNG, JPG, WAV, OGG, GLTF, GLB, OBJ, TTF.
7. **Android Workflow** – configure, export APK, run natively.
8. **Usability** – beginner can go from template → sprite → movement → Play → Android APK.

## License

TBD (recommended: MIT or zlib for maximum adoption).

---

**Nyx** – make games, not engine code.

## Added in this package revision

- `editor/index.html`: dependency-free browser scene authoring prototype. It supports creating/selecting objects, editing basic transform fields, and importing/exporting `nyx-scene-v1` JSON. It is **not** a live engine viewport and does not yet load/save through the C runtime.
- `templates/2d_topdown/main.c`: starter top-down movement example using the current input/object API.
- `android/README.md`: reproducible NDK CMake build instructions for the ARM64 native library. This is not yet an APK exporter; an Android Activity/NativeActivity shell and platform bridge are still required.

## Important implementation status

This is still an early engine foundation. The current platform loop is a stub; there is no production OpenGL renderer, GPU texture upload, glTF/OBJ decoder, Box2D integration, audio backend, Lua VM binding, Android touch bridge, or complete APK packaging pipeline in this source tree. The public APIs for several of these systems are placeholders. The editor is a separate prototype, not a finished integrated editor. Do not interpret a successful static-library build as proof that these runtime features work.

### Suggested native dependency integration

The next engineering milestone is to vendor or fetch pinned versions of GLFW (desktop window/input), OpenGL loader + renderer, Box2D (2D physics), miniaudio (audio), cgltf/tinyobjloader (model import), and Lua 5.4. Each backend should be optional in CMake and covered by a small runtime test before being advertised as supported. Android additionally needs an NDK NativeActivity/JNI backend, EGL/GLES renderer, touch/gamepad input, Gradle packaging, and device testing.
