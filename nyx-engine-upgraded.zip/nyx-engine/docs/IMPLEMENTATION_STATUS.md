# Implementation status after foundation upgrade

## Implemented in this revision
- Fixed-step 2D rigidbody integration with gravity, mass, force and basic AABB box collision response.
- Portable CPU framebuffer with clear and rectangle drawing, suitable for tests and as a backend presentation boundary.
- Browser-based scene editor preview: object hierarchy, basic inspector, canvas preview, JSON save/load.
- Android ARM64 NDK configuration starter.
- Six project template manifests and starter documentation.

## Still requires real backend work
- GLFW/SDL window creation, OpenGL context and GPU sprite/model rendering. The CPU surface is not a substitute for hardware rendering.
- Box2D/Jolt integration (current physics is deliberately basic 2D AABB, not a full rigid-body solver).
- Production audio decoding/mixing, Lua VM binding, glTF/OBJ parsing, texture decoding and animation playback.
- Full editor integration with native runtime, drag/drop asset import, undo/redo and play-in-editor.
- Android NativeActivity/EGL/input implementation, Gradle app module, signing and automated APK packaging.

Optional third-party integrations are intentionally not fetched automatically; add pinned dependencies and licenses before shipping.
