# Nyx Engine Architecture

## Goals

- Extremely easy for beginners (high-level API + visual editor)
- Lightweight C11 core
- Native performance
- Desktop (Linux/Windows) + Android

## Layers

```
┌─────────────────────────────────────────────────────┐
│  Visual Editor (future) + Project Templates         │
├─────────────────────────────────────────────────────┤
│  High-level C API  (nyx.h)  + optional Lua          │
├─────────────────────────────────────────────────────┤
│  Scene / Object / Component / Prefab system         │
├─────────────────────────────────────────────────────┤
│  Systems: Render | Physics | Audio | Input | Assets │
├─────────────────────────────────────────────────────┤
│  Platform Abstraction (Window, GL/Vulkan, Android)  │
└─────────────────────────────────────────────────────┘
```

## Object Model

- Every `NyxObject` has a transform (position, rotation, scale).
- Components are added via `nyx_add_*` helpers.
- Parent-child hierarchy is supported.
- Prefabs allow instancing.

## Data-Oriented Future

The current implementation uses classic OOP-style components for simplicity and readability (matching the “easy first” goal). Later stages can move hot paths (transforms, sprites, physics) to contiguous arrays / SoA without changing the public API.

## Platform Backend Plan

1. **Desktop**: GLFW + OpenGL 3.3 (or Vulkan) for maximum portability.
2. **Android**: Native Activity + OpenGL ES / Vulkan, no emulator required.
3. **Audio**: miniaudio (single-header) or OpenAL.
4. **Physics**: Box2D (2D) + Jolt or custom (3D).
5. **Assets**: stb_image, cgltf, dr_wav / miniaudio.

## Editor Plan

The editor will be a separate executable that links against the same Nyx core. It will use an immediate-mode UI (Dear ImGui) or a retained UI, with:

- Scene Hierarchy panel
- 2D/3D Viewport with gizmo
- Inspector (property grid)
- Asset Browser with drag-and-drop
- Console
- Project Settings + Android export dialog
- Animation timeline

Play mode will run the game in a subprocess or embedded context so the editor stays responsive.
