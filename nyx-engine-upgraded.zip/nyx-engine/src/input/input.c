#include "../core/nyx_internal.h"

/* Simple keyboard state – real implementation would be filled by platform layer */
static bool s_key_down[NYX_KEY_COUNT];
static bool s_key_pressed[NYX_KEY_COUNT];
static bool s_key_released[NYX_KEY_COUNT];

static bool s_mouse_down[3];
static bool s_mouse_pressed[3];
static NyxVec2 s_mouse_pos;
static NyxVec2 s_mouse_delta;

bool nyx_input_pressed(NyxKey key)
{
    if (key < 0 || key >= NYX_KEY_COUNT) return false;
    return s_key_pressed[key];
}

bool nyx_input_down(NyxKey key)
{
    if (key < 0 || key >= NYX_KEY_COUNT) return false;
    return s_key_down[key];
}

bool nyx_input_released(NyxKey key)
{
    if (key < 0 || key >= NYX_KEY_COUNT) return false;
    return s_key_released[key];
}

bool nyx_mouse_pressed(NyxMouseButton btn)
{
    if (btn < 0 || btn > 2) return false;
    return s_mouse_pressed[btn];
}

bool nyx_mouse_down(NyxMouseButton btn)
{
    if (btn < 0 || btn > 2) return false;
    return s_mouse_down[btn];
}

NyxVec2 nyx_mouse_position(void) { return s_mouse_pos; }
NyxVec2 nyx_mouse_delta(void)    { return s_mouse_delta; }

int nyx_touch_count(void) { return 0; } /* Android later */
NyxVec2 nyx_touch_position(int index) { (void)index; return (NyxVec2){0,0}; }

/* Called by platform each frame to clear edge-triggered state */
void nyx_input_end_frame(void)
{
    memset(s_key_pressed, 0, sizeof(s_key_pressed));
    memset(s_key_released, 0, sizeof(s_key_released));
    memset(s_mouse_pressed, 0, sizeof(s_mouse_pressed));
    s_mouse_delta = (NyxVec2){0, 0};
}

/* Platform calls these */
void nyx_input_set_key(NyxKey key, bool down)
{
    if (key < 0 || key >= NYX_KEY_COUNT) return;
    if (down && !s_key_down[key]) s_key_pressed[key] = true;
    if (!down && s_key_down[key]) s_key_released[key] = true;
    s_key_down[key] = down;
}

void nyx_input_set_mouse_button(NyxMouseButton btn, bool down)
{
    if (btn < 0 || btn > 2) return;
    if (down && !s_mouse_down[btn]) s_mouse_pressed[btn] = true;
    s_mouse_down[btn] = down;
}

void nyx_input_set_mouse_pos(float x, float y)
{
    s_mouse_delta.x = x - s_mouse_pos.x;
    s_mouse_delta.y = y - s_mouse_pos.y;
    s_mouse_pos.x = x;
    s_mouse_pos.y = y;
}
