/**
 * Internal structures - not part of public API
 */

#ifndef NYX_INTERNAL_H
#define NYX_INTERNAL_H

#include "nyx/nyx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define NYX_MAX_OBJECTS     4096
#define NYX_MAX_CHILDREN    64
#define NYX_MAX_COMPONENTS  16
#define NYX_NAME_LEN        64
#define NYX_PATH_LEN        256

/* Component types */
typedef enum {
    NYX_COMP_TRANSFORM = 0,
    NYX_COMP_SPRITE,
    NYX_COMP_MODEL,
    NYX_COMP_CAMERA,
    NYX_COMP_RIGIDBODY,
    NYX_COMP_COLLIDER,
    NYX_COMP_ANIMATION,
    NYX_COMP_SCRIPT,
    NYX_COMP_COUNT
} NyxComponentType;

struct NyxComponent {
    NyxComponentType type;
    void *data;
};

struct NyxObject {
    char name[NYX_NAME_LEN];
    NyxScene *scene;
    NyxObject *parent;
    NyxObject *children[NYX_MAX_CHILDREN];
    int child_count;

    /* Transform (always present) */
    NyxVec3 position;
    NyxVec3 rotation; /* euler degrees */
    NyxVec3 scale;

    NyxComponent components[NYX_MAX_COMPONENTS];
    int component_count;

    bool active;
    bool destroyed;
};

struct NyxScene {
    NyxGame *game;
    char name[NYX_NAME_LEN];
    NyxObject *objects[NYX_MAX_OBJECTS];
    int object_count;
    NyxObject *root; /* optional root for hierarchy */
};

struct NyxCamera {
    NyxObject *owner;
    bool orthographic;
    float size;          /* ortho */
    float fov;           /* perspective */
    float near_plane;
    float far_plane;
};

struct NyxGame {
    char title[128];
    int width, height;
    bool running;

    NyxGameCallbacks callbacks;
    NyxScene *active_scene;
    NyxScene **scenes;
    int scene_count;
    int scene_capacity;

    NyxCamera *active_camera;

    /* Physics */
    NyxVec3 gravity;

    /* Time */
    float time;
    float delta_time;
    float fixed_dt;

    /* Platform / window handle (opaque) */
    void *window;
    void *renderer;
    void *audio;
    void *physics_world;
};

void nyx_physics_step(NyxGame *game, float dt);

/* Internal helpers */
NyxComponent *nyx_object_add_component(NyxObject *obj, NyxComponentType type, void *data);
void *nyx_object_get_component(NyxObject *obj, NyxComponentType type);

#endif /* NYX_INTERNAL_H */
