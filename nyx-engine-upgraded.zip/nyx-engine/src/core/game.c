#include "nyx_internal.h"
#include <stdarg.h>
#include <time.h>

/* Platform stubs - replace with real backend (GLFW + Vulkan/OpenGL, etc.) */
static void platform_init(NyxGame *game);
static void platform_shutdown(NyxGame *game);
static void platform_poll_events(NyxGame *game);
static void platform_swap_buffers(NyxGame *game);
static double platform_get_time(void);

NyxGame *nyx_game_create(const char *title, int width, int height)
{
    NyxGame *game = (NyxGame *)calloc(1, sizeof(NyxGame));
    if (!game) return NULL;

    strncpy(game->title, title ? title : "Nyx Game", sizeof(game->title) - 1);
    game->width = width > 0 ? width : 1280;
    game->height = height > 0 ? height : 720;
    game->running = false;
    game->gravity = (NyxVec3){0.0f, 980.0f, 0.0f}; /* default 2D-style gravity */
    game->fixed_dt = 1.0f / 60.0f;
    game->scene_capacity = 8;
    game->scenes = (NyxScene **)calloc(game->scene_capacity, sizeof(NyxScene *));

    platform_init(game);
    nyx_log("Nyx Engine %d.%d.%d initialized (%dx%d)", 
            NYX_VERSION_MAJOR, NYX_VERSION_MINOR, NYX_VERSION_PATCH,
            game->width, game->height);
    return game;
}

void nyx_game_destroy(NyxGame *game)
{
    if (!game) return;

    for (int i = 0; i < game->scene_count; i++) {
        if (game->scenes[i]) nyx_scene_destroy(game->scenes[i]);
    }
    free(game->scenes);

    nyx_render_shutdown();
    platform_shutdown(game);
    free(game);
}

void nyx_game_set_callbacks(NyxGame *game, const NyxGameCallbacks *cb)
{
    if (game && cb) game->callbacks = *cb;
}

int nyx_run(NyxGame *game)
{
    if (!game) return 1;

    game->running = true;
    double last = platform_get_time();
    float accumulator = 0.0f;

    if (game->callbacks.on_start)
        game->callbacks.on_start(game);

    while (game->running) {
        double now = platform_get_time();
        game->delta_time = (float)(now - last);
        last = now;
        if (game->delta_time > 0.25f) game->delta_time = 0.25f; /* clamp */
        game->time += game->delta_time;

        platform_poll_events(game);

        /* Fixed update for physics */
        accumulator += game->delta_time;
        while (accumulator >= game->fixed_dt) {
            if (game->callbacks.on_fixed_update)
                game->callbacks.on_fixed_update(game, game->fixed_dt);
            nyx_physics_step(game, game->fixed_dt);
            accumulator -= game->fixed_dt;
        }

        if (game->callbacks.on_update)
            game->callbacks.on_update(game, game->delta_time);

        if (game->callbacks.on_render)
            game->callbacks.on_render(game);

        platform_swap_buffers(game);
    }

    if (game->callbacks.on_stop)
        game->callbacks.on_stop(game);

    return 0;
}

void nyx_set_gravity(NyxGame *game, float x, float y)
{
    if (game) {
        game->gravity.x = x;
        game->gravity.y = y;
        game->gravity.z = 0.0f;
    }
}

void nyx_set_gravity3(NyxGame *game, float x, float y, float z)
{
    if (game) {
        game->gravity.x = x;
        game->gravity.y = y;
        game->gravity.z = z;
    }
}

float nyx_get_delta_time(const NyxGame *game) { return game ? game->delta_time : 0.0f; }
float nyx_get_time(const NyxGame *game)       { return game ? game->time : 0.0f; }
int   nyx_get_width(const NyxGame *game)      { return game ? game->width : 0; }
int   nyx_get_height(const NyxGame *game)     { return game ? game->height : 0; }

/* Logging */
void nyx_log(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    printf("[Nyx] ");
    vprintf(fmt, args);
    printf("\n");
    va_end(args);
}

void nyx_log_error(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    fprintf(stderr, "[Nyx ERROR] ");
    vfprintf(stderr, fmt, args);
    fprintf(stderr, "\n");
    va_end(args);
}

/* -------------------------------------------------------------------------- */
/* Minimal platform stubs (replace with real windowing + rendering)            */
/* -------------------------------------------------------------------------- */

static void platform_init(NyxGame *game)
{
    (void)game;
    /* TODO: create window (GLFW / SDL / Win32 / X11), init renderer, audio, physics */
    nyx_log("Platform: stub initialized (no real window yet)");
}

static void platform_shutdown(NyxGame *game)
{
    (void)game;
}

static void platform_poll_events(NyxGame *game)
{
    (void)game;
    /* TODO: process window events, update input state */
    /* For now we just keep running; real code would check close request */
}

static void platform_swap_buffers(NyxGame *game)
{
    (void)game;
    /* TODO: present frame */
}

static double platform_get_time(void)
{
    /* Simple monotonic-ish time using clock() – replace with high-res timer */
    return (double)clock() / (double)CLOCKS_PER_SEC;
}
