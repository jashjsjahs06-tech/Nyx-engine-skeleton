#include "../core/nyx_internal.h"

/* Simple component data structs */
typedef struct {
    char texture_path[NYX_PATH_LEN];
    NyxColor tint;
    bool flip_x, flip_y;
    NyxTexture *texture; /* loaded handle */
} NyxSpriteData;

typedef struct {
    char model_path[NYX_PATH_LEN];
    NyxMesh *mesh;
} NyxModelData;

typedef struct {
    NyxBodyType type;
    float mass;
    NyxVec3 velocity;
    NyxVec3 force;
} NyxRigidbodyData;

typedef struct {
    enum { NYX_COLL_BOX, NYX_COLL_CIRCLE, NYX_COLL_SPHERE } shape;
    float w, h, d; /* box */
    float radius;
} NyxColliderData;

typedef struct {
    char path[NYX_PATH_LEN];
    char current[64];
    bool playing;
    bool loop;
} NyxAnimData;

typedef struct {
    NyxScript script;
    bool has_script;
    char lua_path[NYX_PATH_LEN];
} NyxScriptData;

/* Sprite */
void nyx_add_sprite(NyxObject *obj, const char *texture_path)
{
    nyx_add_sprite_color(obj, texture_path, (NyxColor){1, 1, 1, 1});
}

void nyx_add_sprite_color(NyxObject *obj, const char *texture_path, NyxColor tint)
{
    if (!obj) return;
    NyxSpriteData *data = (NyxSpriteData *)calloc(1, sizeof(NyxSpriteData));
    if (!data) return;
    if (texture_path)
        strncpy(data->texture_path, texture_path, sizeof(data->texture_path) - 1);
    data->tint = tint;
    nyx_object_add_component(obj, NYX_COMP_SPRITE, data);
    nyx_log("Added sprite '%s' to %s", texture_path ? texture_path : "", obj->name);
}

void nyx_sprite_set_flip(NyxObject *obj, bool flip_x, bool flip_y)
{
    NyxSpriteData *d = (NyxSpriteData *)nyx_object_get_component(obj, NYX_COMP_SPRITE);
    if (d) { d->flip_x = flip_x; d->flip_y = flip_y; }
}

/* Model */
void nyx_add_model(NyxObject *obj, const char *model_path)
{
    if (!obj) return;
    NyxModelData *data = (NyxModelData *)calloc(1, sizeof(NyxModelData));
    if (!data) return;
    if (model_path)
        strncpy(data->model_path, model_path, sizeof(data->model_path) - 1);
    nyx_object_add_component(obj, NYX_COMP_MODEL, data);
    nyx_log("Added model '%s' to %s", model_path ? model_path : "", obj->name);
}

/* Camera */
NyxCamera *nyx_add_camera(NyxObject *obj)
{
    if (!obj) return NULL;
    NyxCamera *cam = (NyxCamera *)calloc(1, sizeof(NyxCamera));
    if (!cam) return NULL;
    cam->owner = obj;
    cam->orthographic = true;
    cam->size = 10.0f;
    cam->fov = 60.0f;
    cam->near_plane = 0.1f;
    cam->far_plane = 1000.0f;
    nyx_object_add_component(obj, NYX_COMP_CAMERA, cam);

    if (obj->scene && obj->scene->game && !obj->scene->game->active_camera)
        obj->scene->game->active_camera = cam;

    return cam;
}

void nyx_camera_set_orthographic(NyxCamera *cam, float size)
{
    if (cam) { cam->orthographic = true; cam->size = size; }
}

void nyx_camera_set_perspective(NyxCamera *cam, float fov_degrees, float near, float far)
{
    if (cam) {
        cam->orthographic = false;
        cam->fov = fov_degrees;
        cam->near_plane = near;
        cam->far_plane = far;
    }
}

void nyx_camera_set_active(NyxGame *game, NyxCamera *cam)
{
    if (game) game->active_camera = cam;
}

/* Physics */
void nyx_add_rigidbody(NyxObject *obj, NyxBodyType type)
{
    if (!obj) return;
    NyxRigidbodyData *data = (NyxRigidbodyData *)calloc(1, sizeof(NyxRigidbodyData));
    if (!data) return;
    data->type = type;
    data->mass = 1.0f;
    nyx_object_add_component(obj, NYX_COMP_RIGIDBODY, data);
    nyx_log("Added rigidbody (%d) to %s", (int)type, obj->name);
}

void nyx_add_box_collider(NyxObject *obj, float width, float height)
{
    if (!obj) return;
    NyxColliderData *data = (NyxColliderData *)calloc(1, sizeof(NyxColliderData));
    if (!data) return;
    data->shape = NYX_COLL_BOX;
    data->w = width; data->h = height; data->d = 1.0f;
    nyx_object_add_component(obj, NYX_COMP_COLLIDER, data);
}

void nyx_add_box_collider3(NyxObject *obj, float w, float h, float d)
{
    if (!obj) return;
    NyxColliderData *data = (NyxColliderData *)calloc(1, sizeof(NyxColliderData));
    if (!data) return;
    data->shape = NYX_COLL_BOX;
    data->w = w; data->h = h; data->d = d;
    nyx_object_add_component(obj, NYX_COMP_COLLIDER, data);
}

void nyx_add_circle_collider(NyxObject *obj, float radius)
{
    if (!obj) return;
    NyxColliderData *data = (NyxColliderData *)calloc(1, sizeof(NyxColliderData));
    if (!data) return;
    data->shape = NYX_COLL_CIRCLE;
    data->radius = radius;
    nyx_object_add_component(obj, NYX_COMP_COLLIDER, data);
}

void nyx_add_sphere_collider(NyxObject *obj, float radius)
{
    if (!obj) return;
    NyxColliderData *data = (NyxColliderData *)calloc(1, sizeof(NyxColliderData));
    if (!data) return;
    data->shape = NYX_COLL_SPHERE;
    data->radius = radius;
    nyx_object_add_component(obj, NYX_COMP_COLLIDER, data);
}

void nyx_rigidbody_set_velocity(NyxObject *obj, float vx, float vy)
{
    NyxRigidbodyData *d = (NyxRigidbodyData *)nyx_object_get_component(obj, NYX_COMP_RIGIDBODY);
    if (d) { d->velocity.x = vx; d->velocity.y = vy; }
}

void nyx_rigidbody_set_velocity3(NyxObject *obj, float vx, float vy, float vz)
{
    NyxRigidbodyData *d = (NyxRigidbodyData *)nyx_object_get_component(obj, NYX_COMP_RIGIDBODY);
    if (d) { d->velocity.x = vx; d->velocity.y = vy; d->velocity.z = vz; }
}

NyxVec2 nyx_rigidbody_get_velocity(const NyxObject *obj)
{
    NyxRigidbodyData *d = (NyxRigidbodyData *)nyx_object_get_component((NyxObject *)obj, NYX_COMP_RIGIDBODY);
    if (d) return (NyxVec2){d->velocity.x, d->velocity.y};
    return (NyxVec2){0, 0};
}

void nyx_rigidbody_add_force(NyxObject *obj, float fx, float fy)
{
    NyxRigidbodyData *d = (NyxRigidbodyData *)nyx_object_get_component(obj, NYX_COMP_RIGIDBODY);
    if (d) { d->force.x += fx; d->force.y += fy; }
}

void nyx_rigidbody_set_mass(NyxObject *obj, float mass)
{
    NyxRigidbodyData *d = (NyxRigidbodyData *)nyx_object_get_component(obj, NYX_COMP_RIGIDBODY);
    if (d) d->mass = mass > 0.0f ? mass : 1.0f;
}

/* Animation */
void nyx_add_animation(NyxObject *obj, const char *anim_path)
{
    if (!obj) return;
    NyxAnimData *data = (NyxAnimData *)calloc(1, sizeof(NyxAnimData));
    if (!data) return;
    if (anim_path) strncpy(data->path, anim_path, sizeof(data->path) - 1);
    nyx_object_add_component(obj, NYX_COMP_ANIMATION, data);
}

void nyx_play_animation(NyxObject *obj, const char *name, bool loop)
{
    NyxAnimData *d = (NyxAnimData *)nyx_object_get_component(obj, NYX_COMP_ANIMATION);
    if (d) {
        if (name) strncpy(d->current, name, sizeof(d->current) - 1);
        d->playing = true;
        d->loop = loop;
    }
}

void nyx_stop_animation(NyxObject *obj)
{
    NyxAnimData *d = (NyxAnimData *)nyx_object_get_component(obj, NYX_COMP_ANIMATION);
    if (d) d->playing = false;
}

/* Script */
void nyx_add_script(NyxObject *obj, const NyxScript *script)
{
    if (!obj || !script) return;
    NyxScriptData *data = (NyxScriptData *)calloc(1, sizeof(NyxScriptData));
    if (!data) return;
    data->script = *script;
    data->has_script = true;
    nyx_object_add_component(obj, NYX_COMP_SCRIPT, data);
}

void nyx_add_lua_script(NyxObject *obj, const char *lua_path)
{
    if (!obj) return;
    NyxScriptData *data = (NyxScriptData *)calloc(1, sizeof(NyxScriptData));
    if (!data) return;
    if (lua_path) strncpy(data->lua_path, lua_path, sizeof(data->lua_path) - 1);
    nyx_object_add_component(obj, NYX_COMP_SCRIPT, data);
    nyx_log("Lua script '%s' attached to %s (Lua runtime not yet linked)", 
            lua_path ? lua_path : "", obj->name);
}
