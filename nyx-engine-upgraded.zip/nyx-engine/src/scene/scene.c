#include "../core/nyx_internal.h"

NyxScene *nyx_scene_create(NyxGame *game)
{
    if (!game) return NULL;

    NyxScene *scene = (NyxScene *)calloc(1, sizeof(NyxScene));
    if (!scene) return NULL;

    scene->game = game;
    snprintf(scene->name, sizeof(scene->name), "Scene_%d", game->scene_count);

    if (game->scene_count >= game->scene_capacity) {
        game->scene_capacity *= 2;
        game->scenes = (NyxScene **)realloc(game->scenes, 
            game->scene_capacity * sizeof(NyxScene *));
    }
    game->scenes[game->scene_count++] = scene;

    if (!game->active_scene)
        game->active_scene = scene;

    nyx_log("Scene created: %s", scene->name);
    return scene;
}

void nyx_scene_destroy(NyxScene *scene)
{
    if (!scene) return;

    for (int i = 0; i < scene->object_count; i++) {
        if (scene->objects[i] && !scene->objects[i]->destroyed)
            nyx_object_destroy(scene->objects[i]);
    }

    /* Remove from game */
    NyxGame *game = scene->game;
    if (game) {
        for (int i = 0; i < game->scene_count; i++) {
            if (game->scenes[i] == scene) {
                for (int j = i; j < game->scene_count - 1; j++)
                    game->scenes[j] = game->scenes[j + 1];
                game->scene_count--;
                break;
            }
        }
        if (game->active_scene == scene)
            game->active_scene = game->scene_count > 0 ? game->scenes[0] : NULL;
    }

    free(scene);
}

void nyx_scene_set_active(NyxGame *game, NyxScene *scene)
{
    if (game) game->active_scene = scene;
}

NyxScene *nyx_scene_get_active(NyxGame *game)
{
    return game ? game->active_scene : NULL;
}

bool nyx_scene_save(NyxScene *scene, const char *path)
{
    if (!scene || !path) return false;
    /* TODO: serialize to JSON or binary format */
    nyx_log("Scene save stub: %s -> %s", scene->name, path);
    return true;
}

NyxScene *nyx_scene_load(NyxGame *game, const char *path)
{
    if (!game || !path) return NULL;
    /* TODO: deserialize */
    nyx_log("Scene load stub: %s", path);
    return nyx_scene_create(game);
}
