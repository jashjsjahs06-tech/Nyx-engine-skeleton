#include "../core/nyx_internal.h"

NyxObject *nyx_object_create(NyxScene *scene, const char *name)
{
    if (!scene) return NULL;
    if (scene->object_count >= NYX_MAX_OBJECTS) {
        nyx_log_error("Max objects reached");
        return NULL;
    }

    NyxObject *obj = (NyxObject *)calloc(1, sizeof(NyxObject));
    if (!obj) return NULL;

    strncpy(obj->name, name ? name : "Object", sizeof(obj->name) - 1);
    obj->scene = scene;
    obj->scale = (NyxVec3){1.0f, 1.0f, 1.0f};
    obj->active = true;

    scene->objects[scene->object_count++] = obj;
    return obj;
}

void nyx_object_destroy(NyxObject *obj)
{
    if (!obj || obj->destroyed) return;
    obj->destroyed = true;

    /* Detach children */
    for (int i = 0; i < obj->child_count; i++) {
        if (obj->children[i])
            obj->children[i]->parent = NULL;
    }

    /* Remove from parent */
    if (obj->parent) {
        NyxObject *p = obj->parent;
        for (int i = 0; i < p->child_count; i++) {
            if (p->children[i] == obj) {
                for (int j = i; j < p->child_count - 1; j++)
                    p->children[j] = p->children[j + 1];
                p->child_count--;
                break;
            }
        }
    }

    /* Free component data */
    for (int i = 0; i < obj->component_count; i++) {
        free(obj->components[i].data);
    }

    /* Remove from scene list (lazy – mark destroyed) */
    free(obj);
}

NyxObject *nyx_object_find(NyxScene *scene, const char *name)
{
    if (!scene || !name) return NULL;
    for (int i = 0; i < scene->object_count; i++) {
        NyxObject *o = scene->objects[i];
        if (o && !o->destroyed && strcmp(o->name, name) == 0)
            return o;
    }
    return NULL;
}

const char *nyx_object_get_name(const NyxObject *obj)
{
    return obj ? obj->name : "";
}

void nyx_object_set_parent(NyxObject *obj, NyxObject *parent)
{
    if (!obj) return;

    /* Remove from old parent */
    if (obj->parent) {
        NyxObject *p = obj->parent;
        for (int i = 0; i < p->child_count; i++) {
            if (p->children[i] == obj) {
                for (int j = i; j < p->child_count - 1; j++)
                    p->children[j] = p->children[j + 1];
                p->child_count--;
                break;
            }
        }
    }

    obj->parent = parent;
    if (parent && parent->child_count < NYX_MAX_CHILDREN) {
        parent->children[parent->child_count++] = obj;
    }
}

NyxObject *nyx_object_get_parent(const NyxObject *obj)
{
    return obj ? obj->parent : NULL;
}

int nyx_object_get_child_count(const NyxObject *obj)
{
    return obj ? obj->child_count : 0;
}

NyxObject *nyx_object_get_child(const NyxObject *obj, int index)
{
    if (!obj || index < 0 || index >= obj->child_count) return NULL;
    return obj->children[index];
}

/* Transform */
void nyx_object_set_position(NyxObject *obj, float x, float y, float z)
{
    if (obj) { obj->position.x = x; obj->position.y = y; obj->position.z = z; }
}

void nyx_object_set_position2(NyxObject *obj, float x, float y)
{
    nyx_object_set_position(obj, x, y, 0.0f);
}

NyxVec3 nyx_object_get_position(const NyxObject *obj)
{
    return obj ? obj->position : (NyxVec3){0};
}

void nyx_object_set_rotation(NyxObject *obj, float x, float y, float z)
{
    if (obj) { obj->rotation.x = x; obj->rotation.y = y; obj->rotation.z = z; }
}

void nyx_object_set_rotation2(NyxObject *obj, float degrees)
{
    nyx_object_set_rotation(obj, 0, 0, degrees);
}

NyxVec3 nyx_object_get_rotation(const NyxObject *obj)
{
    return obj ? obj->rotation : (NyxVec3){0};
}

void nyx_object_set_scale(NyxObject *obj, float x, float y, float z)
{
    if (obj) { obj->scale.x = x; obj->scale.y = y; obj->scale.z = z; }
}

void nyx_object_set_scale2(NyxObject *obj, float x, float y)
{
    nyx_object_set_scale(obj, x, y, 1.0f);
}

NyxVec3 nyx_object_get_scale(const NyxObject *obj)
{
    return obj ? obj->scale : (NyxVec3){1, 1, 1};
}

/* Component helper */
NyxComponent *nyx_object_add_component(NyxObject *obj, NyxComponentType type, void *data)
{
    if (!obj || obj->component_count >= NYX_MAX_COMPONENTS) return NULL;
    NyxComponent *c = &obj->components[obj->component_count++];
    c->type = type;
    c->data = data;
    return c;
}

void *nyx_object_get_component(NyxObject *obj, NyxComponentType type)
{
    if (!obj) return NULL;
    for (int i = 0; i < obj->component_count; i++) {
        if (obj->components[i].type == type)
            return obj->components[i].data;
    }
    return NULL;
}

/* Prefab stubs */
NyxPrefab *nyx_prefab_create(NyxObject *source)
{
    (void)source;
    nyx_log("Prefab create stub");
    return NULL; /* TODO */
}

NyxObject *nyx_prefab_instantiate(NyxScene *scene, NyxPrefab *prefab)
{
    (void)scene; (void)prefab;
    return NULL;
}

void nyx_prefab_destroy(NyxPrefab *prefab)
{
    (void)prefab;
}
