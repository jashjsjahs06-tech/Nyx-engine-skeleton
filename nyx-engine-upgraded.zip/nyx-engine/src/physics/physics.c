#include "../core/nyx_internal.h"

typedef struct { NyxBodyType type; float mass; NyxVec3 velocity, force; } RigidbodyData;
typedef struct { int shape; float w,h,d,radius; } ColliderData;

/* Deterministic lightweight 2D integrator. Collision response uses AABB overlap;
   production 3D projects should enable the optional Box2D/Jolt adapters. */
void nyx_physics_step(NyxGame *game, float dt) {
    if (!game || !game->active_scene || dt <= 0.0f) return;
    NyxScene *s = game->active_scene;
    for (int i=0;i<s->object_count;i++) {
        NyxObject *o=s->objects[i]; if(!o || !o->active || o->destroyed) continue;
        RigidbodyData *b=(RigidbodyData*)nyx_object_get_component(o,NYX_COMP_RIGIDBODY);
        if(!b || b->type==NYX_BODY_STATIC) continue;
        if(b->type==NYX_BODY_DYNAMIC) {
            float inv=1.0f/(b->mass>0.0001f?b->mass:1.0f);
            b->velocity.x+=(game->gravity.x+b->force.x*inv)*dt;
            b->velocity.y+=(game->gravity.y+b->force.y*inv)*dt;
            b->velocity.z+=(game->gravity.z+b->force.z*inv)*dt;
        }
        o->position.x+=b->velocity.x*dt; o->position.y+=b->velocity.y*dt; o->position.z+=b->velocity.z*dt;
        b->force=(NyxVec3){0,0,0};
    }
    /* Basic axis-aligned 2D collision correction for box colliders. */
    for(int i=0;i<s->object_count;i++) {
        NyxObject *a=s->objects[i]; if(!a||!a->active||a->destroyed) continue;
        ColliderData *ca=(ColliderData*)nyx_object_get_component(a,NYX_COMP_COLLIDER);
        if(!ca||ca->shape!=0) continue;
        for(int j=i+1;j<s->object_count;j++) {
            NyxObject *b=s->objects[j]; if(!b||!b->active||b->destroyed) continue;
            ColliderData *cb=(ColliderData*)nyx_object_get_component(b,NYX_COMP_COLLIDER);
            if(!cb||cb->shape!=0) continue;
            float ax=ca->w*a->scale.x, ay=ca->h*a->scale.y, bx=cb->w*b->scale.x, by=cb->h*b->scale.y;
            float dx=b->position.x-a->position.x, dy=b->position.y-a->position.y;
            float ox=(ax+bx)*0.5f-fabsf(dx), oy=(ay+by)*0.5f-fabsf(dy);
            if(ox>0 && oy>0) {
                RigidbodyData *ra=(RigidbodyData*)nyx_object_get_component(a,NYX_COMP_RIGIDBODY);
                RigidbodyData *rb=(RigidbodyData*)nyx_object_get_component(b,NYX_COMP_RIGIDBODY);
                if(ra && ra->type==NYX_BODY_DYNAMIC) { if(ox<oy) { a->position.x+=(dx<0?-ox:ox)*0.5f; ra->velocity.x=0; } else { a->position.y+=(dy<0?-oy:oy)*0.5f; ra->velocity.y=0; } }
                if(rb && rb->type==NYX_BODY_DYNAMIC) { if(ox<oy) { b->position.x+=(dx<0?ox:-ox)*0.5f; rb->velocity.x=0; } else { b->position.y+=(dy<0?oy:-oy)*0.5f; rb->velocity.y=0; } }
            }
        }
    }
}
