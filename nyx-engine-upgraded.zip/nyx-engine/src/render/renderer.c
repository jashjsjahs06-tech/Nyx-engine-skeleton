#include "../core/nyx_internal.h"
#include <stdint.h>
static uint32_t *pixels; static int fw,fh;
void nyx_render_surface_resize(int w,int h){ if(w<1||h<1||w>8192||h>8192)return; uint32_t *n=(uint32_t*)calloc((size_t)w*h,sizeof(uint32_t)); if(!n)return; free(pixels);pixels=n;fw=w;fh=h; }
void nyx_render_surface_clear(NyxColor c){ if(!pixels)return; uint32_t v=((uint32_t)(c.a*255)<<24)|((uint32_t)(c.r*255)<<16)|((uint32_t)(c.g*255)<<8)|(uint32_t)(c.b*255); for(int i=0;i<fw*fh;i++)pixels[i]=v; }
void nyx_render_rect(int x,int y,int w,int h,NyxColor c){ if(!pixels||w<=0||h<=0)return; int x0=x<0?0:x,y0=y<0?0:y,x1=x+w>fw?fw:x+w,y1=y+h>fh?fh:y+h; uint32_t v=((uint32_t)(c.a*255)<<24)|((uint32_t)(c.r*255)<<16)|((uint32_t)(c.g*255)<<8)|(uint32_t)(c.b*255); for(int yy=y0;yy<y1;yy++)for(int xx=x0;xx<x1;xx++)pixels[yy*fw+xx]=v; }
const uint32_t *nyx_render_pixels(int *w,int *h){if(w)*w=fw;if(h)*h=fh;return pixels;}
void nyx_render_shutdown(void){free(pixels);pixels=NULL;fw=fh=0;}
