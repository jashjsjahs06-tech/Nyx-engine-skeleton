#include "../core/nyx_internal.h"

/* Extremely minimal asset stubs.
 * Real implementation would use stb_image, miniaudio / OpenAL, cgltf, etc.
 */

NyxTexture *nyx_load_texture(NyxGame *game, const char *path)
{
    (void)game;
    if (!path) return NULL;
    nyx_log("Load texture stub: %s", path);
    /* Return a dummy non-null pointer for now so call sites don't crash */
    return (NyxTexture *)(uintptr_t)1;
}

NyxSound *nyx_load_sound(NyxGame *game, const char *path)
{
    (void)game;
    if (!path) return NULL;
    nyx_log("Load sound stub: %s", path);
    return (NyxSound *)(uintptr_t)1;
}

NyxMesh *nyx_load_mesh(NyxGame *game, const char *path)
{
    (void)game;
    if (!path) return NULL;
    nyx_log("Load mesh stub: %s", path);
    return (NyxMesh *)(uintptr_t)1;
}

void nyx_play_sound(NyxGame *game, const char *path)
{
    NyxSound *s = nyx_load_sound(game, path);
    if (s) nyx_play_sound_id(s, 1.0f, false);
}

void nyx_play_sound_id(NyxSound *sound, float volume, bool loop)
{
    (void)sound; (void)volume; (void)loop;
    nyx_log("Play sound stub");
}

void nyx_stop_sound(NyxSound *sound)
{
    (void)sound;
}
